<?php
    class index{
        public function __construct()
        {
            echo "anda sedang berada di controller \n";
        }
        public function index(){
            echo "anda sedang berada di index action \n";
        }
        public function indexAlt($param1, $param2){
            echo `anda sedang berada di index axction dengan param {$param1}, {$param2} \n`;
        }
        public function home(){
            echo "anda sedang berada di index home \n";
        }
    }
?>