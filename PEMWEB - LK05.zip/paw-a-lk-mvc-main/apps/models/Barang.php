<?php
    class Barang{
        private $id;
        private $name;
        private $quantity;

        public function __construct()
        {
            $this->id = 101;
            $this->name = 'Beras';
            $this->quantity = 100;
        }

        public function GetData(){
            return ["id"=>$this->id, "nama"=>$this->name,"kuantitas"=>$this->quantity
        ];
        }
    }
?>