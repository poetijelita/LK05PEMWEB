
    <table>
        <tr>
            <th>ID</th>
            <th>Nama Barang</th>
            <th>QTY</th>
        </tr>
        <tr>
            <?php 
                foreach($data as $item):
            ?>
            <th><?= $item['id']?></th>
            <th><?= $item['nama']?></th>
            <th><?= $item['kuantitas']?></th>
            </tr>
            <?php endforeach?>
    </table>
