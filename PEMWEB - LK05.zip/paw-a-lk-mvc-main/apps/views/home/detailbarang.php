<ul>
    <li>ID: <?= $data['id']?></li>
    <li>Nama: <?= $data['nama']?></li>
    <li>Kuantitas: <?= $data['kuantitas']?></li>
</ul>