<?php
    require_once("apps/boot.php");

    $boot = new Boot();
?>